define("dijit/form/nls/mk/validate", {      
//begin v1.x content
	invalidMessage: "Внесената вредност не е важечка.",
	missingMessage: "Вредноста е задолжителна.",
	rangeMessage: "Вредноста е надвор од опсегот."
//end v1.x content
});

